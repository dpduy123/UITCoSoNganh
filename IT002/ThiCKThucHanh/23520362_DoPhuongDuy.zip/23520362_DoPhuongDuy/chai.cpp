#include "chai.h"

Chai::Chai() {}

void Chai::Xuat() const{
    
}
double Chai::DienTich() {
    return 0;
}

double Chai::TheTich() {
    return 0;
}

double Chai::TyLeRuou() {
    return 0;
}
double Chai::LuongRuou() {
    return 0;
}