#ifndef CHAI_H
#define CHAI_H

#include <bits/stdc++.h> 
using namespace std;

class Chai{
protected:
    
public:
    Chai();
    virtual double DienTich();
    virtual double TheTich();
    virtual double TyLeRuou();
    virtual double LuongRuou();
};


#endif